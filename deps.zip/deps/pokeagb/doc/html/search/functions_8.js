var searchData=
[
  ['interrupts_5fdisable',['interrupts_disable',['../io_8h.html#affac3752e5ab41a28061e0cfdbffa7fb',1,'io.h']]],
  ['interrupts_5fenable',['interrupts_enable',['../io_8h.html#a899920718e09bd866b954960c9c0ddb9',1,'io.h']]],
  ['is_5flight_5flevel_5f1_5f2_5f3_5for_5f6_5f_5fopensky',['is_light_level_1_2_3_or_6__opensky',['../map_8h.html#a24b34a07f01c053cb79631b9d69e3288',1,'map.h']]]
];
