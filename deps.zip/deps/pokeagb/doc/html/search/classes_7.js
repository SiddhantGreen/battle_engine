var searchData=
[
  ['learnsetentry',['LearnsetEntry',['../structLearnsetEntry.html',1,'']]]
];
