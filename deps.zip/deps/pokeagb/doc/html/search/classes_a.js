var searchData=
[
  ['oamdata',['OamData',['../structOamData.html',1,'']]],
  ['object',['Object',['../structObject.html',1,'']]],
  ['overworld_5feffects_5fstate',['overworld_effects_state',['../structoverworld__effects__state.html',1,'']]]
];
