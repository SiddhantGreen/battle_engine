var searchData=
[
  ['winin_5fbuild',['WININ_BUILD',['../io_8h.html#a6eb016699eb9cee2afd185d2e3ae62a7',1,'io.h']]],
  ['winout_5fbuild',['WINOUT_BUILD',['../io_8h.html#acc272be070afd8a167bf362433f6303c',1,'io.h']]]
];
