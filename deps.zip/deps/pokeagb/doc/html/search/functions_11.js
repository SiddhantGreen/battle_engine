var searchData=
[
  ['var_5faccess',['var_access',['../overworld_2script_8h.html#a53d9ca1b576453a83b595b72f516a1c2',1,'script.h']]],
  ['var_5fload',['var_load',['../overworld_2script_8h.html#a73a326e5030c3e3ae928ea6c61a45bd8',1,'script.h']]],
  ['var_5fset',['var_set',['../overworld_2script_8h.html#a0c242b34998b9011541881455ce45d12',1,'script.h']]],
  ['vblank_5fhandler_5fset',['vblank_handler_set',['../callback_8h.html#aef7f88f4e590936f429e2c0a4820d9c9',1,'callback.h']]]
];
