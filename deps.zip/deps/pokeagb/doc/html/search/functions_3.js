var searchData=
[
  ['decompress_5fwith_5ffallback_5fmaybe',['decompress_with_fallback_maybe',['../background_8h.html#ab758456dadba16a17c9ba5233206d74a',1,'background.h']]],
  ['dex_5fflag',['dex_flag',['../pokedex_8h.html#a424a04e5135a9f6f03762767c9ee45c7',1,'pokedex.h']]],
  ['dex_5fflag_5fpokedex_5findex',['dex_flag_pokedex_index',['../pokedex_8h.html#a6dcbccf4f6a7c54283c87e1de5741890',1,'pokedex.h']]],
  ['dialogid_5fwas_5facknowledged',['dialogid_was_acknowledged',['../string_8h.html#ab2c638b39d32185a381960a3878e54f2',1,'string.h']]],
  ['dp01_5fbattle_5fside_5fmark_5fbuffer_5ffor_5fexecution',['dp01_battle_side_mark_buffer_for_execution',['../command_8h.html#ac6d9f9ee5a5087a888bdc17e4ee07efd',1,'command.h']]],
  ['dp01_5fbuild_5fcmdbuf_5fx07',['dp01_build_cmdbuf_x07',['../command_8h.html#a69aed270de64aa5079fde1b08b2f456e',1,'command.h']]],
  ['dp01_5fbuild_5fcmdbuf_5fx09',['dp01_build_cmdbuf_x09',['../command_8h.html#a978b865f3d260070f1debf1b8c8305e6',1,'command.h']]],
  ['dp01_5fbuild_5fcmdbuf_5fx10',['dp01_build_cmdbuf_x10',['../command_8h.html#ad558e2f32d1ffa54a41c6b88960dde1f',1,'command.h']]],
  ['dp01_5fbuild_5fcmdbuf_5fx21_5fa_5fbb',['dp01_build_cmdbuf_x21_a_bb',['../command_8h.html#ad46228c13ee10aab6ede54607feb71f0',1,'command.h']]],
  ['dp01_5fbuild_5fcmdbuf_5fx22',['dp01_build_cmdbuf_x22',['../command_8h.html#a064749dcdefe0f70015ceef2a0bc75b1',1,'command.h']]],
  ['dp01_5fbuild_5fcmdbuf_5fx34',['dp01_build_cmdbuf_x34',['../command_8h.html#a2c7b38d10975fdde65763a9560f4663f',1,'command.h']]],
  ['dp01_5fprepare_5fbuffer',['dp01_prepare_buffer',['../command_8h.html#ac975df8577d18c1f9bb3c2750e612e3e',1,'command.h']]]
];
