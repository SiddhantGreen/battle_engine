var searchData=
[
  ['dispcnt_5fblank',['DISPCNT_BLANK',['../io_8h.html#a54280b91854c245b2be36958f0de82b4',1,'io.h']]],
  ['dispcnt_5fcgb',['DISPCNT_CGB',['../io_8h.html#a5ac91103c3dd4b4e210680a71207a125',1,'io.h']]],
  ['dispcnt_5foam_5fhblank',['DISPCNT_OAM_HBLANK',['../io_8h.html#ae7e7df0cd251118e547deebbb0654dff',1,'io.h']]],
  ['dispcnt_5fpage',['DISPCNT_PAGE',['../io_8h.html#ac9820e637f13b6116155f2c28473c2dc',1,'io.h']]],
  ['dispstat_5fbuild',['DISPSTAT_BUILD',['../io_8h.html#ad0a70ca1f78950fe6494547d201682d3',1,'io.h']]]
];
