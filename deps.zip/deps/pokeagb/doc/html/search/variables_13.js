var searchData=
[
  ['walkrun_5fstate',['walkrun_state',['../npc_8h.html#a137175d6c6ce0f8363365ff64d6c6864',1,'npc.h']]],
  ['wild_5fpokemon_5fdata',['wild_pokemon_data',['../map_8h.html#af1e2ce561aefb9970181d354227edc7f',1,'map.h']]]
];
