var searchData=
[
  ['absent_5fflags_5ffor_5fbanks',['absent_flags_for_banks',['../battle_2data_8h.html#a0ab95cef51f10d1ba6a360c1fab01448',1,'data.h']]],
  ['affine_5fmode',['affine_mode',['../structOamData.html#a366e909e138456d46a5203b75f06adca',1,'OamData']]],
  ['amount',['amount',['../structSignpostData.html#a4b688f1e705fc166a91bffbd819b9363',1,'SignpostData']]],
  ['anim_5fimage_5fempty',['anim_image_empty',['../graphics_2sprites_8h.html#aee96e9163aeba29af94d71c40b150e11',1,'sprites.h']]],
  ['argument',['argument',['../structEvolutionEntry.html#a0cca4d1193dcee39d2d8bb7d40fd5b15',1,'EvolutionEntry']]]
];
