var searchData=
[
  ['new_5fgame',['new_game',['../loading_8h.html#aa7d0559cd1397ca3eeb0dcdf061dd12e',1,'loading.h']]],
  ['npc_5fchange_5fsprite',['npc_change_sprite',['../npc_8h.html#a2dc9f7c00b199aca2aca915138d5c0ee',1,'npc.h']]],
  ['npc_5fhalf_5freset',['npc_half_reset',['../npc_8h.html#a60b78ff42d91955cb95fc842ddb32a92',1,'npc.h']]],
  ['npc_5fhalf_5freset_5fno_5fchecks',['npc_half_reset_no_checks',['../npc_8h.html#a59def3f277d7e3f6be50149a8ef5d774',1,'npc.h']]],
  ['npc_5fhalf_5freset_5fwhen_5fbit7_5fis_5fset',['npc_half_reset_when_bit7_is_set',['../npc_8h.html#aaf9668a2c0ebd580d75a8ef6dc0d1174',1,'npc.h']]],
  ['npc_5fid_5fby_5flocal_5fid',['npc_id_by_local_id',['../npc_8h.html#a80f9e02816c8390d667e3498e3754a25',1,'npc.h']]],
  ['npc_5fid_5fby_5flocal_5fid_5fand_5fmap_5fret_5fsuccess',['npc_id_by_local_id_and_map_ret_success',['../npc_8h.html#a4d1c4006fd0159178fcb8577acb9ca9c',1,'npc.h']]],
  ['npc_5finstanciation_5fsomething',['npc_instanciation_something',['../npc_8h.html#a3b9e8985260f304b211dd8e12350dba3',1,'npc.h']]],
  ['npc_5fset_5fstate_5f2',['npc_set_state_2',['../npc_8h.html#af9c034cef92f2d93180c50fcc300a8ee',1,'npc.h']]],
  ['npc_5fturn',['npc_turn',['../npc_8h.html#a2d3f2f846147758dd37f991166615c17',1,'npc.h']]]
];
