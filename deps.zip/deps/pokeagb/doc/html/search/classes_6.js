var searchData=
[
  ['itemdata',['ItemData',['../structItemData.html',1,'']]],
  ['itemtype',['ItemType',['../unionItemType.html',1,'']]]
];
